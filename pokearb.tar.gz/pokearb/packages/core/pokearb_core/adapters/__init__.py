"""PokeArb core subpackage."""
